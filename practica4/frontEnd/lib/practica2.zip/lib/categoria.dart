enum Categoria { cosmeticos, alimentacion, ropa, ninguna }
